<?php







$host="localhost";
$db_user="u122541238_efg_cuzn_root";
$db_password="Forsan@2023";
$db_name="u122541238_efg_elcuzn";


/*

$host="localhost";
$db_user="root";
$db_password="";
$db_name="getmonyfromgmail";

*/





$con = mysqli_connect($host,$db_user,$db_password,$db_name);

/*
if($con){

echo "con";
}

else{
    echo "not con";

}
*/

?>