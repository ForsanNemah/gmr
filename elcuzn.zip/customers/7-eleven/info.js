 


var phn="966555879644";
var end_date="20-3-2023";
var end_time="12:00";
var ad_source="snap chat ";
var action_url="https://script.google.com/macros/s/AKfycby3yPbDbWGd2VoMdTWuWjkZ3iFBqJJZK36c8SFdgo53FaxygNc5ZcBRokbwl-VIRQ4F/exec";






 