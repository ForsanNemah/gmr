        <!------------ JavaScript Style ------------>
        <script src="lay/lib/jquery_v3.6.3.js"></script>
        <script src="lay/lib/bootstrap.bundle.min.js"></script>
        <script src="lay/lib/chosen.jquery.min.js"></script>
        <script src="lay/lib/clipboard.min.js"></script>
        <script src="lay/js/main.js"></script>
        </body>
</html>